search
follow
followers and following
stories
comments
share
save
menu and logout